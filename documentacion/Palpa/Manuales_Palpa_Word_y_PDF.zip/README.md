# Manuales actualizados de Palpa

Actualización del 23 de noviembre de 2026 · v2_palpa ce5e82170c0b · esquema 8

Este suplemento actualiza la edición base del 10 de noviembre de 2026 en las funciones indicadas. La referencia es el código en GitHub y las pruebas de la versión. La configuración y el despliegue en producción quedan por verificar.

| Documento | PDF completo | Inicio del suplemento | Word editable |
|---|---:|---:|---|
| Manual del sistema PALPA | 49 páginas | Página 48 | Manual_del_sistema_PALPA.docx |
| Manual tecnico PALPA | 46 páginas | Página 45 | Manual_tecnico_PALPA.docx |
| Cuaderno de talleres PALPA | 63 páginas | Página 63 | Cuaderno_de_talleres_PALPA.docx |
| Diagrama base de datos PALPA | 7 páginas | Página 7 | Diagrama_base_de_datos_PALPA.docx |
